/**
 * Created by Murugavel C of bahwancybertek.com
 * Intel-Offline Question
 *
 */

Intel - Offline Question

**This code reads the first two columns of an Excel file.Just upload the excel which available in the source folder(data.xlsx)**